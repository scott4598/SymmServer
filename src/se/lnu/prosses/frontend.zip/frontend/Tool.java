package se.lnu.prosses.frontend;

import java.io.File;

import org.apache.commons.io.FilenameUtils;

import se.lnu.prosses.core.JimpleProjectHelper;
import se.lnu.prosses.utils.Configuration;
import se.lnu.prosses.utils.Constants;
import se.lnu.prosses.utils.SymmariesAnalysis;
import se.lnu.prosses.utils.SymmariesHeapDom;
import se.lnu.prosses.utils.Utils;
import soot.options.Options;

public class Tool {
    public Configuration configurations = new Configuration(SymmariesAnalysis.IMPLICIT_CONF, true);
    public JimpleProjectHelper project;
    public int processedApplications = 0;

    public static String getVariantCode(SymmariesAnalysis analysis, SymmariesHeapDom heapDom, int methskip,
	    boolean exceptionsEnabled, String realibReorder, String timeout, String cuddMem) {
	return getVariantCode(analysis, heapDom.toString(), methskip, exceptionsEnabled, realibReorder, timeout,
		cuddMem);
    }

    public static String getVariantCode(SymmariesAnalysis analysis, String heapDomCode, int methskip,
	    boolean exceptionsEnabled, String realibReorder, String timeout, String cuddMem) {
	return String.join("_", "", analysis.toString(), exceptionsEnabled ? "+exceptions" : "-exceptions", heapDomCode,
		// "\""+ "${heapDomain}\"",
		methskip >= 0 ? Integer.toString(methskip) : "", realibReorder, "timeout=" + timeout,
		"cuddmem=" + cuddMem, "");
    }

    protected String getVariantCode(Configuration config) {
	return getVariantCode(config.analysis, "\"${heapDomain}\"",
		// config.heapDom,
		config.methodSkipParameter, config.exceptionsEnabled, config.realibReorder, config.timeout,
		config.cuddMem);
    }

    protected String buildSymmariesCommand(Configuration config) {
	// int index = 0;
	// String[] scgsAlgorithms = new String[]{
	// "\'sS:d={P:m},split_outer=false\'",
	// "\'sS:d={P:m},split_outer=true\'",
	// "\'sS\'",
	// "\'sB:rp={stop_dri=1,stop_ri=100,log}\'"};
	String variant = getVariantCode(config);

	String commonOptions = String.join(" ", "-ll w",
		"-tf " + (String.join(",", config.exceptionsEnabled ? "+exceptions" : "-exceptions",
			config.analysis.getTransFlags(), // (config.taintCheckingEnabled ? "+enforce_integrity-levels" :
			// (config.explicitConfEnabeled? ",levels=explicit": ""))
			// config.heapDom.getTransFlags()
			config.heapDom.getvarHeapDomain())));
	String synthOptions = String.join(" ", "-of secsum" + (config.generateSyrsScfg ? "+scfg" : ""),
		"-rf " + config.realibReorder, "-rf cuddmem=" + config.cuddMem, "-pf timeout=" + config.timeout)
		+ (config.methodSkipParameter >= 0 ? " --methskip-cond " + config.methodSkipParameter : "");

	// Dirs and files

	String targetDirVar = "${dir}";
	String targetDir = targetDirVar + File.separator;
	String typesProcStatsFile = targetDir + "types" + Constants.proc_statsFileExtension;
	String classesStatsFile = targetDir + "types" + Constants.class_statsFileExtension;
	String classesFile = targetDir + "types.classes";
	String classesBinFile = targetDir + "types.classes_bin";
	String oldScgsTypeVersFile = targetDir + "types.syrs-version";
	String secSumsBase = targetDir + "Meth" + File.separator;

	String outputFileName = targetDir + Constants.statsFilePrefix + "${variant}";
	String analyzisProcStatsFile = outputFileName + Constants.analysis_proc_statsFileExtension;
	String oldScgsVersFile = outputFileName + ".syrs-version";

	// commands

	// String setTargetDir = "dir=\"/home/ubuntu/SyrsWorks/"+ new
	// File(qte(Utils.polishFilePath(config.outputPath))).getName() +";";
	String setTargetDir = "dir=" + qte(Utils.polishFilePath(config.outputPath)) + ";";
	String setVariant = "variant=\"" + getVariantCode(config) + "\";";
	String setSyrsVers = "syrsvers=\"$( " + config.syrsPath + " -V )\";";
	String setHeapDomains = "heapDomains=('" + config.heapDom + "');"; // deep' 'connect' 'share' 'ashare' 'shallow'
									   // 'dumb');";

	String getOldTypeVers = "if test -r " + qte(oldScgsTypeVersFile) + "; then " + "oldtypvers=\"$(< "
		+ qte(oldScgsTypeVersFile) + ")\"; else " + "oldtypvers=\"none\"; " + "fi;";
	String setNewTypeVers = "echo \"${syrsvers}\" > " + qte(oldScgsTypeVersFile);
	String testIfNewTypes = "test ! \"${oldtypvers}\" = \"${syrsvers}\" || " + "test ! -f " + qte(classesBinFile)
		+ " -o " + qte(classesFile) + " -nt " + qte(classesBinFile);

	String getOldVers = "if test -r " + qte(oldScgsVersFile) + "; then " + "oldvers=\"$(< " + qte(oldScgsVersFile)
		+ ")\"; else " + "oldvers=\"none\"; " + "fi;";
	String setNewVers = "echo \"${syrsvers}\" > " + qte(oldScgsVersFile);
	String testIfNewVers = "test ! \"${oldvers}\" = \"${syrsvers}\"";

	String updateTypesBinCmd = String.join(" ", Constants.symmariesEnv,
		// Constants.timeCmd,
		// "-o", qte(typesProcStatsFile),
		config.syrsPath, commonOptions, qte(classesFile), "-o", qte(classesBinFile), "-o",
		qte(classesStatsFile));

	String analyzeCmd = String.join(" ", Constants.symmariesEnv,
		// Constants.timeCmd,
		// "-o", qte(analyzisProcStatsFile),
		config.syrsPath, commonOptions, qte(classesBinFile),
		qte(targetDir + "Meth" + File.separator + "all.secstubs"),
		qte(targetDir + "Meth" + File.separator + "all.meth_files"), synthOptions,
		// "-po sigint=skip,timeout=10m " +
		"--safe-walk", "-o", qte(outputFileName + ".secsums"), "-o", qte(outputFileName + ".meth_stats"));

	return (String.join("\n", setTargetDir, setSyrsVers, getOldVers, getOldTypeVers, setHeapDomains,
		"for heapDomain in \"${heapDomains[@]}\"; do", "  " + setVariant,
		"  if " + testIfNewTypes + "; then \\", "    " + updateTypesBinCmd + " && \\",
		"    " + setNewTypeVers + "; \\", "  fi && \\", "  if " + testIfNewVers + "; then \\",
		"    " + analyzeCmd + " && \\", "    " + setNewVers + " && \\",
		"    for f in " + secSumsBase + "*.secsum; do \\",
		"       mv \"$f\" \"${f%.secsum}.${variant}-secsum\"; \\", "    done; \\", "  fi", "done", "\n"));

    }

    private static String qte(String s) {
	return "\"" + s + "\"";
    }

    public Tool(SymmariesAnalysis analysis, boolean isModelRunFreeVersion) {
	configurations = new Configuration(analysis, isModelRunFreeVersion);
	configurations.monitorHelperPath = "se.lnu.prosses.monitor";
    }

    public Tool() {
	project = new JimpleProjectHelper(configurations);
    }

    public boolean start() {
	project.configurations = configurations;
	project.clear();
	project.loadSecstubsFromXMLFile();
	project.loadAssumedSecuritySignatures();
	project.extractSourceSinkFromXML();
	project.extractSourceSinksFromSecuritySignatures();
	boolean res = compileApplication();
	project.writeErrLog();
	return res;
    }

    public void writeSymmariesFile() {
	configurations.syrsCommand = buildSymmariesCommand(configurations);
	String cmdFile = !configurations.syrsCommandFile.equals("") ? configurations.syrsCommandFile
		: (FilenameUtils.removeExtension(configurations.syrsCommandFile) + "_"
			+ this.getVariantCode(configurations) + "."
			+ FilenameUtils.getExtension(configurations.syrsCommandFile));
	File cmd = new File(cmdFile);
	String cmdPath = cmd.getAbsolutePath();
	if (cmd.getParent() != null) {
	    Utils.createDirectory(cmd.getParent());
	    if (!cmd.exists() && !Utils.createFile(cmdPath))
		;
	    else if (!Utils.writeTextFile(cmdPath, "#!/bin/bash\n" + configurations.syrsCommand))
		Utils.log(getClass(), "Could not write the Symmaries command file " + cmdPath);
	} else
	    Utils.logErr(getClass(),
		    "The path " + cmdPath + " does not exist. Failed to write the Syrs commands file.");

    }

    public boolean compileApplication() {
	if (configurations.loadFromApk) {
	    return project.constructSymmariesInputFromClassFiles(Options.src_prec_apk);
	} else {
	    return project.constructSymmariesInputFromClassFiles(Options.src_prec_java);
	}
    }

    /*
     * public String getInputPath() { return inputPath; }
     * 
     * public void setInputPath(String inputPath) { this.inputPath = inputPath; }
     * 
     * public String getOutputPath() { return outputPath; }
     * 
     * public void setOutputPath(String outputPath) { this.outputPath = outputPath;
     * }
     */

}
