/**
 *
 */
package se.lnu.prosses.frontend;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;

import se.lnu.prosses.utils.SymmariesAnalysis;

/**
 * @author nakhaa
 *
 */
public class APKApplicationHelper extends Tool {

    /**
     * @param exConifidentiality
     * @param imConifidentiality
     * @param integrity
     * @param isModelRunFreeVersion
     */
    public APKApplicationHelper(SymmariesAnalysis analysis, boolean isModelRunFreeVersion) {
	super(analysis, isModelRunFreeVersion);
    }

    /**
     * @param inputpath
     * @param outputpath
     * @param inputFolderpath
     */

    void buildConfigurationForAPK(String applicationName, String appPath, String targetFolder, String exprType,
	    boolean exceptionEnabeled, String scgsCommandFile) {
	String androidJDKPath = new File(configurations.appPath).getParent() + "/Config/android-4.1.1.4.jar";
	String[] requiredClassesPaths = new String[] { androidJDKPath, };
	configurations.outputPath = configurations.outputPath + java.io.File.separator + targetFolder
		+ java.io.File.separator + applicationName + java.io.File.separator + exprType + java.io.File.separator;
	configurations.appPath = appPath + java.io.File.separator + applicationName;
	configurations.requiredClassesPaths = requiredClassesPaths;
	configurations.syrsPath = "syrs.opt";
	configurations.monitorHelperPath = "se.lnu.prosses.monitor";
	configurations.xmlSourcesAndSinks = new File(configurations.appPath).getParent()
		+ "/Config/SourcesAndSinks.txt";
	configurations.assumedSecSigsFilePath = new String[] {
		new File(configurations.appPath).getParent() + "/Config/assumedSecSigsNoSinks.presecsig" };
	configurations.callbacks = new File(configurations.appPath).getParent() + "/Config/AndriodCallbacks.txt";
	configurations.loadFromApk = true;
	configurations.exceptionsEnabled = exceptionEnabeled;
	configurations.syrsCommandFile = scgsCommandFile;
    }

    /**
     * @param apkRootDirectory
     * @param outputpath
     * @param excludedApplications
     * @param targetSubpath
     * @param exprType
     * @param generateSCGSInputs
     * @throws Exception
     */

    public void checkAPKsInDirectory(File apkRootDirectory, String outputpath, ArrayList<String> excludedApplications,
	    String targetSubpath, String exprType, boolean exceptionEnabeled, String scgsCommandFile,
	    boolean generateSCGSInputs) throws Exception {
	FilenameFilter apkFilter = new FilenameFilter() {
	    @Override
	    public boolean accept(File dir, String name) {
		return name.toLowerCase().endsWith(".apk");
	    }
	};
	if (apkRootDirectory.exists()) {
	    File[] apkFiles = apkRootDirectory.listFiles(apkFilter);
	    for (File apkfile : apkFiles)
		if (!excludedApplications.contains(apkfile.getName())) {
		    processSingleAPKFile(apkfile.getName(), apkRootDirectory.getAbsolutePath(),
			    targetSubpath + java.io.File.separator + apkRootDirectory.getName(), exprType,
			    exceptionEnabeled, scgsCommandFile, generateSCGSInputs);
		    processedApplications++;
		}

	    String[] directories = apkRootDirectory.list(new FilenameFilter() {
		@Override
		public boolean accept(File current, String name) {
		    return new File(current, name).isDirectory();
		}
	    });

	    for (String directory : directories) {
		File subDirectory = new File(apkRootDirectory + java.io.File.separator + directory);
		checkAPKsInDirectory(subDirectory, outputpath, excludedApplications, targetSubpath, exprType,
			exceptionEnabeled, scgsCommandFile, generateSCGSInputs);
	    }
	} else
	    System.out.println("Could not find the directory " + apkRootDirectory.getAbsolutePath());
    }

    void processSingleAPKFile(String applicationName, String appPath, String targetFolder, String exprType,
	    boolean exceptionEnabeled, String scgsCommandFile, boolean generateSCGSInputs) throws Exception {
	System.out.println("\n\nprocessSingleAPKFile(" + applicationName + "," + appPath + "," + targetFolder);
	String methodName = null;
	buildConfigurationForAPK(applicationName, appPath, targetFolder, exprType, exceptionEnabeled, scgsCommandFile);
	System.out.println("Starting tool with:" + configurations.appPath);
	if (generateSCGSInputs)
	    start();
	/*
	 * System.out.println("Running SCGS"); runSCGSv2();
	 * System.out.println("Extracting the analysis results ");
	 * extractSCGSResults(applicationName);
	 */
	System.out.println("Finished processing the application " + applicationName
		+ ".\n----------------------------------------------------------------\n\n\n");
	System.out.println("Writting the command file");
	writeSymmariesFile();
    }

}
