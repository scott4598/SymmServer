package se.lnu.prosses.frontend;

import java.io.File;

import org.apache.commons.lang3.ArrayUtils;

import se.lnu.prosses.utils.Configuration;
import se.lnu.prosses.utils.SymmariesAnalysis;
import se.lnu.prosses.utils.SymmariesHeapDom;
import se.lnu.prosses.utils.TypeHandlingConfig;
import se.lnu.prosses.utils.Utils;

public final class JSymCompiler {

    private static final String DEFAULT_SYRS_PATH = "syrs.opt";
    private static final String TOOL_GUIDE;

    static {
	TOOL_GUIDE = String.join("\n",
		"\nJisymCompiler takes a Jar file as input and generates the input (including the command) required to run Symmaries.",
		"", "You can find the command to run Symmaries in the target folder (symmariesCommand.command).", "",
		"Usage: java -jar PathToJSymCompiler.jar jarFileName [options]", "", "Options:",
		"  -o <folder> Output folder", "  -ss <file> Source/sink file (xml format)",
		"  -sp <file> Path to the Symmaries executable file", "  -tf <file> Security summary file",
		"  -cp <cp> Application classpath (given to soot)",
		"  -analysis <analysis> Analysis performed by the generated command script (see syrs.opt's help message)",
		"  -heapdom <heapdom> Heap domain used by the generated command script (default is deep)",
		"  -SO Enable relevant soot optimization phases (disabled by default)",
		"  +runSyrs Enables executing Symmaries (after generating the Symmaries's input files)", "");
    }

    private JSymCompiler() {
	// Utility class
    }

    private static void usage(int status) {
	System.out.println(TOOL_GUIDE);
	System.exit(status);
    }

    public static void main(String[] args) throws Exception {
	if (args.length == 0) {
	    Utils.log(JSymCompiler.class, "Please enter a JAR file for analysis.");
	    usage(1);
	}

	if ("--help".equalsIgnoreCase(args[0]) || "-h".equalsIgnoreCase(args[0])) {
	    usage(0);
	}

	Configuration configuration = buildConfigSetting(args);

	if (configuration == null) {
	    Utils.log(JSymCompiler.class, "Failed to set the configurations.");
	    return;
	}

	JARApplicationHelper jarHelper = new JARApplicationHelper();
	String jarContentPath = configuration.outputPath + File.separator + "jarContent";

	jarHelper.processSingleJARFile(new File(configuration.appPath), jarContentPath, null, configuration);

	Utils.delete(new File(jarContentPath));

	if (configuration.runSyrs) {
	    if (jarHelper.configurations.syrsPath.isEmpty()) {
		Utils.log(JSymCompiler.class, "Symmaries path is missing.");
		System.exit(0);
	    }

	    if (!Utils.runSymmaries(jarHelper.configurations.syrsCommandFile, jarHelper.configurations.syrsCommand)) {
		Utils.log(JSymCompiler.class,
			"You may manually run the command in the file " + configuration.syrsCommandFile);
	    }
	} else {
	    Utils.log(JSymCompiler.class, "The path to the command file is " + configuration.syrsCommandFile);
	}

	Utils.log(JSymCompiler.class, "Finished processing the application!");
    }

    private static Configuration buildConfigSetting(String[] args) {
	String jarFilePath = absolutePath(args[0]);
	if (jarFilePath.isEmpty()) {
	    Utils.log(JSymCompiler.class, "The file " + args[0] + " does not exist.");
	    System.exit(0);
	}

	if (!jarFilePath.endsWith(".jar")) {
	    Utils.log(JSymCompiler.class, "Please enter a valid JAR file.");
	    System.exit(0);
	}

	String targetPath = null;
	String xmlSrcSinkFilePath = "";
	String symmariesPath = "";
	String extraClasspath = null;
	SymmariesAnalysis analysis = SymmariesAnalysis.IMPLICIT_CONF;
	SymmariesHeapDom heapDom = SymmariesHeapDom.DEEPALIAS;
	boolean enableJimpleOptimizationPack = false;
	boolean enableSootOptimizations = false;
	boolean runSyrs = false;
	String[] secsumFilePath = null;

	// Parse arguments
	for (int i = 1; i < args.length; i++) {
	    switch (args[i]) {
	    case "-o":
		targetPath = absolutePath(args[++i]);
		if (targetPath.isEmpty() || !new File(targetPath).isDirectory()) {
		    Utils.log(JSymCompiler.class, "The output folder " + args[i] + " does not exist. Creating it.");
		    Utils.createDirectory(args[i]);
		    targetPath = absolutePath(args[i]);
		}
		break;
	    case "-ss":
		xmlSrcSinkFilePath = absolutePath(args[++i]);
		if (xmlSrcSinkFilePath.isEmpty()) {
		    Utils.log(JSymCompiler.class, "The source/sink file " + args[i] + " does not exist.");
		    System.exit(0);
		}
		break;
	    case "-sp":
		symmariesPath = absolutePath(args[++i]);
		if (symmariesPath.isEmpty()) {
		    Utils.log(JSymCompiler.class, "Symmaries path " + args[i] + " may not exist.");
		}
		break;
	    case "-tf":
		String secFile = absolutePath(args[++i]);
		if (secFile.isEmpty()) {
		    Utils.log(JSymCompiler.class, "Security summary file " + args[i] + " does not exist.");
		    System.exit(0);
		}
		secsumFilePath = ArrayUtils.add(secsumFilePath, secFile);
		break;
	    case "-cp":
		extraClasspath = args[++i];
		break;
	    case "-analysis":
		analysis = SymmariesAnalysis.ofString(args[++i]);
		break;
	    case "+taints":
		analysis = SymmariesAnalysis.TAINT;
		break;
	    case "-heapdom":
		heapDom = SymmariesHeapDom.ofString(args[++i]);
		break;
	    case "-SO":
		enableSootOptimizations = true;
		break;
	    case "-JO":
		enableJimpleOptimizationPack = true;
		break;
	    case "+runSyrs":
		runSyrs = true;
		break;
	    case "--help":
	    case "-h":
		usage(0);
		break;
	    default:
		Utils.log(JSymCompiler.class, "Unknown argument " + args[i] + ". Skipped.");
	    }
	}

	if (xmlSrcSinkFilePath.isEmpty()) {
	    Utils.log(JSymCompiler.class, "Source/sink file is missing.");
	}

	if (symmariesPath.isEmpty()) {
	    Utils.log(JSymCompiler.class, "Symmaries path is missing. Using default path.");
	    symmariesPath = DEFAULT_SYRS_PATH;
	}

	if (targetPath == null) {
	    targetPath = new File(jarFilePath).getParent() + File.separator + "Syrs";
	    Utils.log(JSymCompiler.class, "Target folder is missing. Set it to " + targetPath);
	}

	TypeHandlingConfig typeHandlingConfig = new TypeHandlingConfig(true, // skipMethodsWithIncompatibleTypes
		false, // autoFixInconsistentTypes
		false // allowIncompatibleTypes
	);

	String[] extraClassPathArray = extraClasspath == null ? new String[] {} : new String[] { extraClasspath };
	String commandFilePath = targetPath + File.separator + "syrsCommand.command";

	Configuration config = new Configuration();
	config.buildConfiguration(jarFilePath, targetPath, ArrayUtils.add(extraClassPathArray, ""), secsumFilePath,
		xmlSrcSinkFilePath, "", false, symmariesPath, runSyrs, commandFilePath, analysis, heapDom, 300, false,
		enableSootOptimizations, enableJimpleOptimizationPack, true, typeHandlingConfig, false);

	return config;
    }

    private static String absolutePath(String file) {
	if (file.trim().isEmpty())
	    return "";
	File f = new File(file);
	if (f.exists())
	    return f.getAbsolutePath();
	f = new File(System.getProperty("user.dir"), file);
	return f.exists() ? f.getAbsolutePath() : "";
    }
}
