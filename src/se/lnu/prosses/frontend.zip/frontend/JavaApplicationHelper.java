package se.lnu.prosses.frontend;

import se.lnu.prosses.utils.Configuration;
import se.lnu.prosses.utils.SymmariesAnalysis;
import se.lnu.prosses.utils.Utils;

public class JavaApplicationHelper extends Tool {

	public JavaApplicationHelper(SymmariesAnalysis analysis,
			boolean isModelRunFreeVersion) {
		super(analysis, isModelRunFreeVersion);
	}

	public JavaApplicationHelper() {
		// TODO Auto-generated constructor stub
	}


	public boolean processSingleJavaApplication(		
			String appPath,
			//boolean loadApk,
			Configuration pconfiguration) {

		if(!pconfiguration.loadFromApk)
			if(Utils.getFilesOfTypes(appPath, new String[]{".class"}).size()==0) {
				Utils.log(this.getClass(), "The application in "+ appPath +" has no class files. Skipping");
				return false;
			}

		configurations = pconfiguration;
		Utils.log(this.getClass(), "Loading the tool with: " + pconfiguration.appPath);
		if(start()) {
			Utils.log(this.getClass(), "Finished processing the application " + appPath
					);
		} else
			return false;

		writeSymmariesFile();

		return true;
	}

}
