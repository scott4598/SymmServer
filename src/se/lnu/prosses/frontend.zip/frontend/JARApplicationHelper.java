/**
 *
 */
package se.lnu.prosses.frontend;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.HashMap;

import se.lnu.prosses.utils.Configuration;
import se.lnu.prosses.utils.SymmariesAnalysis;
import se.lnu.prosses.utils.SymmariesHeapDom;
import se.lnu.prosses.utils.TypeHandlingConfig;
import se.lnu.prosses.utils.Utils;

/**
 * @author nakhaa
 *
 */
public class JARApplicationHelper extends JavaApplicationHelper {
    // private String jarFilePath;

    // public boolean specializeCommandFileName;

    public JARApplicationHelper(SymmariesAnalysis analysis, boolean isModelRunFreeVersion) {
	super(analysis, isModelRunFreeVersion);
    }

    public JARApplicationHelper() {
	super();
    }

    public void checkJARsInDirectory(File jarRootDirectory, ArrayList<String> excludedApplications, String exprType,
	    String[] secsumfilePath, String xmlSecstubsFileName, HashMap<String, String> classesFolderMap,
	    String[] extraClassPath, boolean exceptionEnabeled, boolean generateSCGSInputs, String symmariesPth,
	    String scgscommandFilePath, SymmariesAnalysis analysis, SymmariesHeapDom heapDom, int methodSkipParameter,
	    boolean loadApk, boolean enableSootOptimizations, boolean enableJimpleOptimizationPack,
	    boolean abortOnError, TypeHandlingConfig typeHandlingConfig, boolean generateJimple) {
	if (jarRootDirectory.exists()) {
	    for (File jarfile : Utils.getFilesOfTypes(jarRootDirectory.getAbsolutePath(),
		    new String[] { ".jar", ".war" }))
		if (!excludedApplications.contains(jarfile.getAbsolutePath())) {
		    String outputSubdirectory = jarfile.getAbsolutePath().replaceAll(configurations.appPath, "");
		    String jarContentPath = configurations.outputPath
			    + outputSubdirectory.substring(0, outputSubdirectory.lastIndexOf(".")) + File.separator
			    + "JarContent";
		    Configuration pconfiguration = new Configuration();
		    pconfiguration.buildConfiguration(jarfile.getAbsolutePath(), jarContentPath, extraClassPath,
			    secsumfilePath, ((jarfile).getParentFile()).getParent() + File.separator + "rifl.xml",
			    xmlSecstubsFileName, exceptionEnabeled, symmariesPth, false, scgscommandFilePath, analysis,
			    heapDom, methodSkipParameter, loadApk, enableSootOptimizations,
			    enableJimpleOptimizationPack, abortOnError, typeHandlingConfig, generateJimple);

		    if (processSingleJARFile(jarfile, jarContentPath, classesFolderMap, pconfiguration))
			processedApplications++;
		}
	    Utils.log(this.getClass(), processedApplications + " applications have been processed!");
	} else
	    Utils.log(this.getClass(), "Could not find the directory " + jarRootDirectory.getAbsolutePath());
    }

    public void checkJARFileCollections(ArrayList<File> jarFiles, ArrayList<String> excludedApplications,
	    String exprType, String[] secsumfilePath, String xmlSecstubsFileName,
	    HashMap<String, String> classesFolderMap, String[] extraClassPath, boolean exceptionEnabeled,
	    boolean generateSCGSInputs, String symmariesPth, String scgscommandFilePath, SymmariesAnalysis analysis,
	    SymmariesHeapDom heapDom, int methodSkipParameter, boolean loadApk, boolean enableSootOptimizations,
	    boolean enableJimpleOptimizationPack, boolean abortOnError, TypeHandlingConfig typeHandlingConfig,
	    boolean generateJimple) {
	for (File jarfile : jarFiles) {
	    String outputSubdirectory = jarfile.getAbsolutePath().replaceAll(configurations.appPath, "");
	    String jarContentPath = configurations.outputPath
		    + outputSubdirectory.substring(0, outputSubdirectory.lastIndexOf(".")) + File.separator
		    + "JarContent";

	    Configuration pconfiguration = new Configuration();
	    pconfiguration.buildConfiguration(jarfile.getAbsolutePath(), jarContentPath, extraClassPath, secsumfilePath,
		    ((jarfile).getParentFile()).getParent() + File.separator + "rifl.xml", xmlSecstubsFileName,
		    exceptionEnabeled, symmariesPth, false, scgscommandFilePath, analysis, heapDom, methodSkipParameter,
		    loadApk, enableSootOptimizations, enableJimpleOptimizationPack, abortOnError, typeHandlingConfig,
		    generateJimple);
	    if (processSingleJARFile(jarfile, jarContentPath, classesFolderMap, pconfiguration))
		processedApplications++;
	}
    }

    public void checkApplicationsInDirectory(File directory, String targetFolder,
	    ArrayList<String> excludedApplications, String xmlSrcSinkFileName, String xmlSecstubsFileName,
	    String[] secsumfilePath, HashMap<String, String> classesFolderMap, String[] extraClassPath,
	    boolean exceptionEnabeled, boolean generateSCGSInputs, String symmariesPath,
	    String symmariesCommandFilePath, SymmariesAnalysis analysis, SymmariesHeapDom heapDom,
	    int methodSkipParameter, boolean loadApk, boolean enableSootOptimizations,
	    boolean enableJimpleOptimizationPack, boolean abortOnError, TypeHandlingConfig typeHandlingConfig,
	    boolean generateJimple) {

	if (!directory.exists()) {
	    Utils.log(getClass(), "Could not find directory " + directory.getAbsolutePath());
	    return;
	}

	for (String application : Utils.getDirectories(directory.getAbsolutePath())) {

	    if (excludedApplications.contains(application))
		continue;

	    File file = new File(directory + File.separator + application);
	    String jarContentPath = directory + File.separator + application + File.separator + "JarContent";
	    boolean hasWebInf = new File(jarContentPath + File.separator + "/WEB-INF/classes/").exists();
	    String classesFilePath = jarContentPath + File.separator
		    + (hasWebInf ? "/WEB-INF/classes/"
			    : (classesFolderMap != null && classesFolderMap.get(file.getName()) != null
				    ? classesFolderMap.get(file.getName())
				    : ""));

	    Configuration pconfiguration = new Configuration();
	    pconfiguration.buildConfiguration(classesFilePath, targetFolder,
		    (extraClassPath == null ? new String[] { classesFilePath }
			    : org.apache.commons.lang3.ArrayUtils.add(extraClassPath, classesFilePath)),
		    secsumfilePath, directory.getAbsolutePath() + File.separator + xmlSrcSinkFileName,
		    xmlSecstubsFileName, exceptionEnabeled, symmariesPath, false, symmariesCommandFilePath, analysis,
		    heapDom, methodSkipParameter, loadApk, enableSootOptimizations, enableJimpleOptimizationPack,
		    abortOnError, typeHandlingConfig, generateJimple);

	    if (processSingleJavaApplication(classesFilePath,
		    // loadApk,
		    pconfiguration))
		processedApplications++;
	    Utils.log(this.getClass(), processedApplications + " applications have been processed!");
	}
    }

    public boolean processSingleJARFile(File jarFilePath, String jarContentPath,
	    HashMap<String, String> classesFolderMap, Configuration pconfiguration) {

	Utils.log(getClass(), "Started Processing " + jarFilePath);
	if (Utils.uncompressZipFile(jarFilePath.getAbsolutePath(), jarContentPath, ".class")) {
	    boolean hasWebInf = new File(jarContentPath + File.separator + "/WEB-INF/classes/").exists();
	    String classesFilePath = jarContentPath + File.separator
		    + (hasWebInf ? "/WEB-INF/classes/"
			    : (classesFolderMap != null && classesFolderMap.get(jarFilePath.getName()) != null
				    ? classesFolderMap.get(jarFilePath.getName())
				    : ""));
	    configurations = pconfiguration;

	    if (processSingleJavaApplication(classesFilePath, pconfiguration))
		return true;
	    else
		return false;
	}
	Utils.logErr(this.getClass(), "Could not uncompress the jar file " + jarFilePath);
	return false;
    }

    public String findClassesFolder(String jarContentPath) {
	if (Utils.getFilesOfTypes(jarContentPath, new String[] { ".class" }).size() == 0)
	    return null;
	String[] directories = new File(jarContentPath).list(new FilenameFilter() {
	    @Override
	    public boolean accept(File current, String name) {
		return new File(current, name).isDirectory();
	    }
	});
	if (directories != null) {
	    boolean[] foldersWithClasses = new boolean[directories.length];
	    int numberOfFoldersWithClasses = 0;
	    for (int index = 0; index < directories.length; index++) {
		ArrayList<File> temp = Utils.getFilesOfTypes(jarContentPath + File.separator + directories[index],
			new String[] { ".class" });
		if (temp != null && temp.size() > 0)
		    numberOfFoldersWithClasses++;
		foldersWithClasses[index] = temp != null && temp.size() > 0;
	    }
	    if (numberOfFoldersWithClasses == 1) {
		for (int index = 0; index < foldersWithClasses.length; index++)
		    if (foldersWithClasses[index])
			return jarContentPath + File.separator + directories[index];
	    } else if (numberOfFoldersWithClasses == 0)
		return jarContentPath;
	}
	return null;

    }

    public void checkApplicationInDirectory(Configuration pconfiguration, String appDir, String classesDir,
	    String[] classpath, HashMap<String, String> classesFolderMap, ArrayList<String> excludedApplications) {

	File directory = new File(appDir);
	if (!directory.exists()) {
	    Utils.log(getClass(), "Could not find directory " + directory.getAbsolutePath());
	    return;
	}

	String application = directory.getName();
	if (excludedApplications.contains(application))
	    return;

	boolean hasWebInf = new File(classesDir + File.separator + "/WEB-INF/classes/").exists();
	String classesFilePath = classesDir + File.separator
		+ (hasWebInf ? "/WEB-INF/classes/"
			: (classesFolderMap != null && classesFolderMap.get(application) != null
				? classesFolderMap.get(application)
				: ""));

	pconfiguration.requiredClassesPaths = (classpath == null ? new String[] { classesFilePath }
		: org.apache.commons.lang3.ArrayUtils.add(classpath, classesFilePath));
	pconfiguration.appPath = classesFilePath;
	if (processSingleJavaApplication(classesFilePath, pconfiguration) && pconfiguration.generateSymmariesInput)
	    Utils.log(getClass(), "Symmaries inputs for " + application + " have been generated.");
    }

}
